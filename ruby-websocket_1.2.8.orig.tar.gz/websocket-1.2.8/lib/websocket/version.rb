# frozen_string_literal: true

module WebSocket
  VERSION = '1.2.8'.freeze
end
