# frozen_string_literal: true

module WebSocket
  module Handshake
    module Handler
      class Server < Base
      end
    end
  end
end
