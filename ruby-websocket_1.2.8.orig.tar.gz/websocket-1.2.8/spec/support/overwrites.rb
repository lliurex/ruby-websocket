# frozen_string_literal: true

module WebSocket
  module Handshake
    class Base
      attr_reader :handler
    end
  end
end
